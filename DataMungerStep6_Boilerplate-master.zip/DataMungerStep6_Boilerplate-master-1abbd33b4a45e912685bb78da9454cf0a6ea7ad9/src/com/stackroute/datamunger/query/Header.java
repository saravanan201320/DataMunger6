package com.stackroute.datamunger.query;

import java.util.HashMap;
import java.util.Map;

//header class containing a Collection containing the headers

public class Header extends HashMap<String, Integer> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	Map<String, Integer> headers;
	
	public Map<String, Integer> getHeaders() {
		return headers;
	}
	
	public void setHeaders(Map<String, Integer> headers) {
		this.headers = headers;
	}
	
	@Override
	public String toString() {
		return "Header [headers=" + headers + "]";
	}	
}
