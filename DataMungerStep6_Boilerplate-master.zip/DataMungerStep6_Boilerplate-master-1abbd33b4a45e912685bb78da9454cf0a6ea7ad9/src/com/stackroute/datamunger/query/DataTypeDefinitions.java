package com.stackroute.datamunger.query;

import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
 * Implementation of DataTypeDefinitions class. This class contains a method getDataTypes() 
 * which will contain the logic for getting the datatype for a given field value. This
 * method will be called from QueryProcessors.   
 * In this assignment, we are going to use Regular Expression to find the 
 * appropriate data type of a field. 
 * Integers: should contain only digits without decimal point 
 * Double: should contain digits as well as decimal point 
 * Date: Dates can be written in many formats in the CSV file. 
 * However, in this assignment,we will test for the following date formats('dd/mm/yyyy',
 * 'mm/dd/yyyy','dd-mon-yy','dd-mon-yyyy','dd-month-yy','dd-month-yyyy','yyyy-mm-dd')
 */
public class DataTypeDefinitions {
	//RegEx for date validation.
	private final String DDMM_REGEX = "^[0-3]?[0-9].[0-3]?[0-9].(?:[0-9]{2})?[0-9]{2}$";
	private final String YYYY_REGEX = "^(?:[0-9]{2})?[0-9]{2}.[0-3]?[0-9].[0-3]?[0-9]$";	
	private final String DD_MON_REGEX = "^[0-3]?[0-9].[a-zA-Z]{3,10}.(?:[0-9]{2})?[0-9]{2}$";		

	public Object getDataType(String input) {

		// check for empty object

		// checking for Integer

		// checking for floating point numbers

		// checking for date format dd/mm/yyyy

		// checking for date format mm/dd/yyyy

		// checking for date format dd-mon-yy

		// checking for date format dd-mon-yyyy

		// checking for date format dd-month-yy

		// checking for date format dd-month-yyyy

		return getFieldDataType(input);
	}

	/**
	 * This method returns actual data type values from the specified string.
	 * @param dataField
	 * @return
	 */
	private String getFieldDataType(String dataField) {
		
		try {
			// checking for Integer			
			Integer.parseInt(dataField);	
			return Integer.class.getName();			
		} catch (NumberFormatException e) {
			// TODO: handle exception
			try {
				// checking for floating point numbers				
				Double.parseDouble(dataField);	
				return Double.class.getName();				
			} catch (NumberFormatException e2) {
				// TODO: handle exception
				//check for date class,
				Pattern pattern = null;
				try {
					// checking for date format yyyy-mm-dd, yyyy/mm/dd and yyyy.mm.dd	
					if(dataField != null && dataField.length() > 3)
					Integer.parseInt(dataField.substring(0, 3));
					pattern = Pattern.compile(YYYY_REGEX);
				} catch (NumberFormatException nfe) {
					// TODO: handle exception
					try {
						//checking for 'dd/mm/yyyy', 'mm/dd/yyyy'
						if(Integer.parseInt(dataField.substring(0, 2)) > 0
								&& Integer.parseInt(dataField.substring(3, 5)) > 0){
							pattern = Pattern.compile(DDMM_REGEX);							
						}
					} catch (NumberFormatException nfe2) {
						// TODO: handle exception
						// checking for date format 'dd-mon-yy','dd-mon-yyyy','dd-month-yy','dd-month-yyyy'
						try {
							//System.out.println("dataField : "+dataField);
							if(dataField.length() > 5 && Integer.parseInt(dataField.substring(3, 6)) > 0){
								pattern = Pattern.compile(DD_MON_REGEX);							
							}							
						} catch (NumberFormatException nfe3) {
							// TODO: handle exception
						}
						String[] dateArr = dataField.split("\\-");
						if(dateArr.length > 1 && dateArr[1].length() > 2)
							pattern = Pattern.compile(DD_MON_REGEX);
					}
				}
				if(pattern != null){
				    Matcher matcher = pattern.matcher(dataField);	
				    //System.out.println("dataField : "+dataField + " matches() : "+matcher.matches());
				    if(matcher.matches()){
				    	return Date.class.getName();
				    }					
				}
				return String.class.getName();			    
			}

		}
		//return String.class.getName();
	}
	
}
