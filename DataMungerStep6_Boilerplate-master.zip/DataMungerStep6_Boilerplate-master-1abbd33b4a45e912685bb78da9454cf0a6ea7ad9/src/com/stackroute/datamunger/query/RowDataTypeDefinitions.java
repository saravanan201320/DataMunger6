package com.stackroute.datamunger.query;

import java.util.HashMap;

//This class will be used to store the column data types as columnIndex/DataType

public class RowDataTypeDefinitions extends HashMap<Integer, String>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private HashMap<Integer, String> dataTypes;
	
	public HashMap<Integer, String> getDataTypes() {
		return dataTypes;
	}
	
	public void setDataTypes(HashMap<Integer, String> dataTypes) {
		this.dataTypes = dataTypes;
	}		
	
}
