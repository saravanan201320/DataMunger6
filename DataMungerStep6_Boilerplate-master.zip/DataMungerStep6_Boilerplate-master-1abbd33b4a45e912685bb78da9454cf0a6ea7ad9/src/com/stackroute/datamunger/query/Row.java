package com.stackroute.datamunger.query;

import java.util.HashMap;

//contains the row object as ColumnName/Value. Hence, HashMap is being used

public class Row extends HashMap<String, String>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private HashMap <String, String>rowData;
	
	public HashMap<String, String> getRowData() {
		return rowData;
	}
	
	public void setRowData(HashMap<String, String> rowData) {
		this.rowData = rowData;
	}		
	
}
