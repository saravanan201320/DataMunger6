package com.stackroute.datamunger.query;

import java.util.Comparator;

/*
 * The GenericComparator class implements Comparator Interface. This class is used to 
 * compare row objects which will be used for sorting the dataSet
 */
public class GenericComparator implements Comparator<Row> {

	private String columnName;
	
	@Override
	public int compare(Row o1, Row o2) {
		// TODO Auto-generated method stub
		return o1.get(getColumnName()).compareTo(o2.get(getColumnName()));
	}
	
	public String getColumnName() {
		return columnName;
	}	
	
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}	

}
