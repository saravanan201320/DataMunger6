package com.stackroute.datamunger.query.parser;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class QueryParser {

	/*
	 * This method will parse the queryString and will return the object of
	 * QueryParameter class
	 */
	public QueryParameter parseQuery(String queryString) {
		
		QueryParameter queryParameter = new QueryParameter();	
		queryParameter.setBaseQuery(getBaseQuery(queryString));		

		/*
		 * extract the name of the file from the query. File name can be found after the
		 * "from" clause.
		 */
		queryParameter.setFileName(getFileName(queryString));
		/*
		 * extract the order by fields from the query string. Please note that we will
		 * need to extract the field(s) after "order by" clause in the query, if at all
		 * the order by clause exists. For eg: select city,winner,team1,team2 from
		 * data/ipl.csv order by city from the query mentioned above, we need to extract
		 * "city". Please note that we can have more than one order by fields.
		 */
		queryParameter.setOrderByFields(getOrderByFields(queryString));
		/*
		 * extract the group by fields from the query string. Please note that we will
		 * need to extract the field(s) after "group by" clause in the query, if at all
		 * the group by clause exists. For eg: select city,max(win_by_runs) from
		 * data/ipl.csv group by city from the query mentioned above, we need to extract
		 * "city". Please note that we can have more than one group by fields.
		 */
		queryParameter.setGroupByFields(getGroupByFields(queryString));
		/*
		 * extract the selected fields from the query string. Please note that we will
		 * need to extract the field(s) after "select" clause followed by a space from
		 * the query string. For eg: select city,win_by_runs from data/ipl.csv from the
		 * query mentioned above, we need to extract "city" and "win_by_runs". Please
		 * note that we might have a field containing name "from_date" or "from_hrs".
		 * Hence, consider this while parsing.
		 */
		queryParameter.setFields(getFields(queryString));
		/*
		 * extract the conditions from the query string(if exists). for each condition,
		 * we need to capture the following: 1. Name of field 2. condition 3. value
		 * 
		 * For eg: select city,winner,team1,team2,player_of_match from data/ipl.csv
		 * where season >= 2008 or toss_decision != bat
		 * 
		 * here, for the first condition, "season>=2008" we need to capture: 1. Name of
		 * field: season 2. condition: >= 3. value: 2008
		 * 
		 * the query might contain multiple conditions separated by OR/AND operators.
		 * Please consider this while parsing the conditions.
		 * 
		 */
		queryParameter.setRestrictions(getConditions(queryString));
		/*
		 * extract the logical operators(AND/OR) from the query, if at all it is
		 * present. For eg: select city,winner,team1,team2,player_of_match from
		 * data/ipl.csv where season >= 2008 or toss_decision != bat and city =
		 * bangalore
		 * 
		 * the query mentioned above in the example should return a List of Strings
		 * containing [or,and]
		 */
		queryParameter.setLogicalOperators(getLogicalOperators(queryString));
		/*
		 * extract the aggregate functions from the query. The presence of the aggregate
		 * functions can determined if we have either "min" or "max" or "sum" or "count"
		 * or "avg" followed by opening braces"(" after "select" clause in the query
		 * string. in case it is present, then we will have to extract the same. For
		 * each aggregate functions, we need to know the following: 1. type of aggregate
		 * function(min/max/count/sum/avg) 2. field on which the aggregate function is
		 * being applied
		 * 
		 * Please note that more than one aggregate function can be present in a query
		 * 
		 * 
		 */
		queryParameter.setAggregateFunctions(getAggregateFunctions(queryString));
		
		return queryParameter;
	}

	/*
	 * This method will split the query string based on space into an array of words
	 * and display it on console
	 */
	public String[] getSplitStrings(String queryString) {
		
		String[] splitQueryString = queryString.split("\\s");
		String[] loweredSplitQueryString = new String[splitQueryString.length];
		for(int i=0; i< splitQueryString.length;i++){
			loweredSplitQueryString[i] = splitQueryString[i].toLowerCase().trim();
		}
		return loweredSplitQueryString;
	}
	/*
	 * Extract the name of the file from the query. File name can be found after a
	 * space after "from" clause. Note: ----- CSV file can contain a field that
	 * contains from as a part of the column name. For eg: from_date,from_hrs etc.
	 * 
	 * Please consider this while extracting the file name in this method.
	 */
	public String getFileName(String queryString) {
		
		int index = queryString.indexOf("from");
		String subString = queryString.substring(index+4);
		String fileNames[] = subString.split("\\s(where|order by|group by)");
		
		return fileNames[0].trim();
	}
	/*
	 * This method is used to extract the baseQuery from the query string. BaseQuery
	 * contains from the beginning of the query till the where clause
	 * 
	 * Note: ------- 1. The query might not contain where clause but contain order
	 * by or group by clause 2. The query might not contain where, order by or group
	 * by clause 3. The query might not contain where, but can contain both group by
	 * and order by clause
	 */
	
	public String getBaseQuery(String queryString) {
		
		String[] splitQueryString = queryString.split("(where|order by|group by)");
		return (splitQueryString[0]).trim();
	}
	/*
	 * This method will extract the fields to be selected from the query string. The
	 * query string can have multiple fields separated by comma. The extracted
	 * fields will be stored in a String array which is to be printed in console as
	 * well as to be returned by the method
	 * 
	 * Note: 1. The field name or value in the condition can contain keywords
	 * as a substring. For eg: from_city,job_order_no,group_no etc. 2. The field
	 * name can contain '*'
	 * 
	 */
	
	public List<String> getFields(String queryString) {
		String baseQuery = getBaseQuery(queryString);
		int fromIndex = baseQuery.indexOf("from");
		String subQuery = baseQuery.substring(7, fromIndex);
		String[] fields = subQuery.split("\\,");
		List<String> trimFields = new ArrayList<>();
		for(int i=0;i<fields.length;i++){
			trimFields.add(fields[i].trim());
		}
		return trimFields;
	}
	/*
	 * This method is used to extract the conditions part from the query string. The
	 * conditions part contains starting from where keyword till the next keyword,
	 * which is either group by or order by clause. In case of absence of both group
	 * by and order by clause, it will contain till the end of the query string.
	 * Note:  1. The field name or value in the condition can contain keywords
	 * as a substring. For eg: from_city,job_order_no,group_no etc. 2. The query
	 * might not contain where clause at all.
	 */
	
	public String getConditionsPartQuery(String queryString) {
		String[] splitQueryString = queryString.split("(where)");
		if(splitQueryString.length >=2){
			String[] splitWhere = splitQueryString[1].split("(order by|group by)");
			return splitWhere[0].trim();
		}
		return null;
	}
	/*
	 * This method will extract condition(s) from the query string. The query can
	 * contain one or multiple conditions. In case of multiple conditions, the
	 * conditions will be separated by AND/OR keywords. for eg: Input: select
	 * city,winner,player_match from ipl.csv where season > 2014 and city
	 * ='Bangalore'
	 * 
	 * This method will return a string array ["season > 2014","city ='bangalore'"]
	 * and print the array
	 * 
	 * Note: ----- 1. The field name or value in the condition can contain keywords
	 * as a substring. For eg: from_city,job_order_no,group_no etc. 2. The query
	 * might not contain where clause at all.
	 */
	public List<Restriction> getConditions(String queryString) {

		List<Restriction> allConditions = null;
		Restriction restriction = null;
		String conditionPartQuery = getConditionsPartQuery(queryString);
		if (conditionPartQuery != null) {
			String[] conditions = conditionPartQuery.split("( or |and)");
			if (conditions.length > 0) {
				allConditions = new ArrayList<Restriction>();
				for (int i = 0; i < conditions.length; i++) {
					String[] restrictFields = conditions[i].trim().split("\\s");
					String fieldName = restrictFields[0].trim();
					String condition = null, value = null;
					if(restrictFields.length == 2){
						condition = restrictFields[1].trim().substring(0, 1);
						value = restrictFields[1].trim().substring(2, restrictFields[1].trim().length()-1);
						
					}else if(restrictFields.length > 1){
						condition = restrictFields[1].trim();
						value = restrictFields[2].trim();
					}else{
						String[] conditionArr = restrictFields[0].split("\\'");
						fieldName = conditionArr[0].substring(0, conditionArr[0].length()-1);
						condition = conditionArr[0].substring(conditionArr[0].length()-1);
						value = conditionArr[1];						
						//restriction = new Restriction(restrictFields[0].substring(0, ), restrictFields[0].trim(), null);						
					}
//					if(value != null && condition != null){
//						restriction = new Restriction(fieldName.trim(), value.trim(), condition.trim());
//					}
					restriction = new Restriction(fieldName.trim(), value.trim(), condition.trim());					
					allConditions.add(restriction);					

				}
			} 
		}

		return allConditions;		
	}
	
	/*
	 * This method will extract logical operators(AND/OR) from the query string. The
	 * extracted logical operators will be stored in a String array which will be
	 * returned by the method and the same will be printed Note:  1. AND/OR
	 * keyword will exist in the query only if where conditions exists and it
	 * contains multiple conditions. 2. AND/OR can exist as a substring in the
	 * conditions as well. For eg: name='Alexander',color='Red' etc. Please consider
	 * these as well when extracting the logical operators.
	 * 
	 */
	public List<String> getLogicalOperators(String queryString) {
		String conditionQuery = getConditionsPartQuery(queryString);
		List <String>operators = new ArrayList<>();
		if(null  != conditionQuery ){
			String[] conditionSplit = conditionQuery.split("(\\s+)");
			
			if(conditionSplit.length >= 2){
				for(int i=0; i<conditionSplit.length;i++){
					if(null != conditionSplit[i] &&
							(conditionSplit[i].trim()).equalsIgnoreCase("and")
							|| conditionSplit[i].trim().equalsIgnoreCase("or")){
						operators.add(conditionSplit[i].trim().toLowerCase());
					}
				}
				 
			}
		}
		if(operators.isEmpty()){
			return null;
		}
		return operators;
	}
	/*
	 * This method extracts the order by fields from the query string. Note: 
	 * 1. The query string can contain more than one order by fields. 2. The query
	 * string might not contain order by clause at all. 3. The field names,condition
	 * values might contain "order" as a substring. For eg:order_number,job_order
	 * Consider this while extracting the order by fields
	 */
	public List<String> getOrderByFields(String queryString) {
		
		List<String> orderByFields = Collections.emptyList(); 
		if(queryString != null && queryString.length() > 0){
			String[] splitQueryString = queryString.split("(order by)");
			orderByFields = new ArrayList<String>();
			if(splitQueryString.length >= 2){
				String[] orderByStringsArray = splitQueryString[1].split("\\,");
				for(int i=0; i< orderByStringsArray.length; i++){
					orderByFields.add(orderByStringsArray[i].toLowerCase().trim());
				}
			}			
		}

		return orderByFields;
	}
	
	/*
	 * This method extracts the group by fields from the query string. Note:
	 * 1. The query string can contain more than one group by fields. 2. The query
	 * string might not contain group by clause at all. 3. The field names,condition
	 * values might contain "group" as a substring. For eg: newsgroup_name
	 * 
	 * Consider this while extracting the group by fields
	 */
	public List<String> getGroupByFields(String queryString) {
		
		List<String> groupByFields = Collections.emptyList();
		if(queryString != null && queryString.length() > 0 && queryString.indexOf("group by") > 0){
			String[] splitQueryString = queryString.split("(group by|order by)");
			if(splitQueryString.length >=2){
				String[] splitGroupBy = splitQueryString[1].split("\\,");;
				groupByFields = new ArrayList<String>();
				for (int i=0;i<splitGroupBy.length;i++){
					groupByFields.add(splitGroupBy[i].trim().toLowerCase());
				}
			}					
		}

		return groupByFields;
	}	
	
	/*
	 * This method extracts the aggregate functions from the query string. Note:
	 *  1. aggregate functions will start with "sum"/"count"/"min"/"max"/"avg"
	 * followed by "(" 2. The field names might
	 * contain"sum"/"count"/"min"/"max"/"avg" as a substring. For eg:
	 * account_number,consumed_qty,nominee_name
	 * 
	 * Consider this while extracting the aggregate functions
	 */
	public List <AggregateFunction> getAggregateFunctions(String queryString) {
		List <AggregateFunction>aggregateFunctions = new ArrayList<>();
		List <String> allFields = getFields(queryString);
		
		if(!allFields.isEmpty()){
			
			for (String field : allFields){
				if(field.startsWith("sum(") || field.startsWith("min(") ||
					field.startsWith("max(") || field.startsWith("avg(") ||
					field.startsWith("count(")){
					int fieldEndIndex = field.indexOf("(");
					String fieldName = field.substring(0, fieldEndIndex);
					String functionName = field.substring(fieldEndIndex+1, field.length()-1);
					AggregateFunction aggregateFunction = new AggregateFunction(functionName.trim().toLowerCase(), fieldName.trim().toLowerCase());
					aggregateFunctions.add(aggregateFunction);
				}
			}
		}
		return aggregateFunctions;
	}	
}
