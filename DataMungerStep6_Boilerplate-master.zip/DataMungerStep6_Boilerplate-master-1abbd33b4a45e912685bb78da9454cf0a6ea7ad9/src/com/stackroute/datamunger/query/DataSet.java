package com.stackroute.datamunger.query;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;

//This class will be acting as the DataSet containing multiple rows

public class DataSet extends LinkedHashMap<Long, Row> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/*
	 * The sort() method will sort the dataSet based on the key column with the help
	 * of Comparator
	 */
	public DataSet sort(RowDataTypeDefinitions dataTypes, String columnName) {

		Collection<Row> rows = this.values();
		DataSet sortedDataSet = new DataSet();
		GenericComparator genericComp = new GenericComparator();
		genericComp.setColumnName(columnName);
		List<Row> list = new ArrayList<>(rows);
	    Collections.sort(list, genericComp);
	    long count = 1;
	    for (Row row : list) {
	    	sortedDataSet.put(count++, row);			
		}
		return sortedDataSet;
	}

}
