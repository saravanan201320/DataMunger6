package com.stackroute.datamunger.query;

import java.util.Date;

import com.stackroute.datamunger.query.parser.Restriction;

//This class contains methods to evaluate expressions
public class Filter {

	/*
	 * the evaluateExpression() method of this class is responsible for evaluating
	 * the expressions mentioned in the query. It has to be noted that the process
	 * of evaluating expressions will be different for different data types. there
	 * are 6 operators that can exist within a query i.e. >=,<=,<,>,!=,= This method
	 * should be able to evaluate all of them. Note: while evaluating string
	 * expressions, please handle uppercase and lowercase
	 * 
	 */
	public static boolean evaluateExpression(final Restriction restriction, final String data, final String dataType){
		boolean evalCondition = false;
		if (restriction.getCondition().equals("=")) {
			evalCondition = checkEqualTo(restriction.getPropertyValue(), data, dataType);
		} else if (restriction.getCondition().equals("!=")) {
			evalCondition = checkNotEqualTo(restriction.getPropertyValue(), data, dataType);
		} else if (restriction.getCondition().equals(">")) {
			evalCondition = checkGreaterThan(restriction.getPropertyValue(), data, dataType);
		} else if (restriction.getCondition().equals(">=")) {
			evalCondition = checkGreaterThanOrEqualTo(restriction.getPropertyValue(), data, dataType);
		} else if (restriction.getCondition().equals("<")) {
			evalCondition = checkLessThan(restriction.getPropertyValue(), data, dataType);
		} else if (restriction.getCondition().equals("<=")) {
			evalCondition = checkLessThanOrEqualTo(restriction.getPropertyValue(), data, dataType);
		} 
		
		return evalCondition;
	}	

	// method to evaluate expression for eg: salary>20000

	// method containing implementation of equalTo operator
	private static boolean checkEqualTo(final String value, final String data, final String dataType){
		boolean check = false;
		if(dataType != null){
			if (dataType.equals("java.lang.Integer")) {
				check = (Integer.parseInt(data) == Integer.parseInt(value))?true:false;
			} else if (dataType.equals("java.lang.Double")) {
				check =  (Double.parseDouble(data) == Double.parseDouble(value))?true:false;
			} else if (dataType.equals("java.lang.Date")) {
				check = (Date.parse(data) == Date.parse(value))?true:false;
			} else {
				check = (data.equals(value))?true:false;
			}			
		}

		return check;
	}		
	
	// method containing implementation of notEequalTo operator
	private static boolean checkNotEqualTo(final String value, final String data, final String dataType){
		boolean check = false;
		if(dataType != null){
			if (dataType.equals("java.lang.Integer")) {
				check = (Integer.parseInt(data) != Integer.parseInt(value))?true:false;
			} else if (dataType.equals("java.lang.Double")) {
				check =  (Double.parseDouble(data) != Double.parseDouble(value))?true:false;
			} else if (dataType.equals("java.lang.Date")) {
				check = (Date.parse(data) != Date.parse(value))?true:false;
			} else {
				check = (!data.equals(value))?true:false;
			}			
		}

		return check;
	}			

	// method containing implementation of greaterThan operator
	private static boolean checkGreaterThan(final String value, final String data, final String dataType){
		boolean check = false;
		if(dataType != null){
			if (dataType.equals("java.lang.Integer")) {
				check = (Integer.parseInt(data) > Integer.parseInt(value))?true:false;
			} else if (dataType.equals("java.lang.Double")) {
				check = (Double.parseDouble(data) > Double.parseDouble(value))?true:false;
			} else if (dataType.equals("java.lang.Date")) {
				check = (Date.parse(data) > Date.parse(value))?true:false;
			} else {
				check = false;
			}			
		}

		return check;
	}		

	// method containing implementation of greaterThanOrEqualTo operator
	private static boolean checkGreaterThanOrEqualTo(final String value, final String data, final String dataType){
		boolean check = false;
		if(dataType != null){
			if (dataType.equals("java.lang.Integer")) {
				check = (Integer.parseInt(data) >= Integer.parseInt(value))?true:false;
			} else if (dataType.equals("java.lang.Double")) {
				check = (Double.parseDouble(data) >= Double.parseDouble(value))?true:false;
			} else if (dataType.equals("java.lang.Date")) {
				check = (Date.parse(data) >= Date.parse(value))?true:false;
			} else {
				check = false;
			}			
		}

		return check;
	}	
	
	// method containing implementation of lessThan operator
	private static boolean checkLessThan(final String value, final String data, final String dataType){
		boolean check = false;
		if(dataType != null){
			if (dataType.equals("java.lang.Integer")) {
				check = (Integer.parseInt(data) < Integer.parseInt(value))?true:false;
			} else if (dataType.equals("java.lang.Double")) {
				check = (Double.parseDouble(data) < Double.parseDouble(value))?true:false;
			} else if (dataType.equals("java.lang.Date")) {
				check = (Date.parse(data) < Date.parse(value))?true:false;
			} else {
				check = false;
			}			
		}

		return check;
	}	  	

	// method containing implementation of lessThanOrEqualTo operator
	private static boolean checkLessThanOrEqualTo(String value, String data, String dataType){
		boolean check = false;
		if(dataType != null){
			if (dataType.equals("java.lang.Integer")) {
				check = (Integer.parseInt(data) <= Integer.parseInt(value))?true:false;
			} else if (dataType.equals("java.lang.Double")) {
				check = (Double.parseDouble(data) <= Double.parseDouble(value))?true:false;
			} else if (dataType.equals("java.lang.Date")) {
				check = (Date.parse(data) <= Date.parse(value))?true:false;
			} else {
				check = false;
			}			
		}

		return check;
	}		
}
